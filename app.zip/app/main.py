from fastapi import FastAPI, HTTPException
from app.routes import router
from model.train import train_model


app = FastAPI()

# Include routes
app.include_router(router)

@app.post("/train/")
def trigger_training():
    try:
        accuracy = train_model("dataset.csv", "model/svm_model.pkl")
        return {"message": "Model trained successfully", "accuracy": accuracy}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/")
def welcome():
    return {"message": "Welcome to the SVM Text Classification API"}
